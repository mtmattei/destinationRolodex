from pathlib import Path
from playwright.sync_api import sync_playwright
from PIL import Image, ImageOps, ImageEnhance
import io,json,os,shutil
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'tests'/'artifacts';OUT.mkdir(exist_ok=True)
base=Image.open(ROOT/'assets/philippines-preview.jpg').convert('RGB').resize((1000,850))
fixtures=[]
for i in range(6):
 im=base.copy()
 if i%2:im=ImageOps.mirror(im)
 if i>0:
  r,g,b=im.split()
  im=Image.merge('RGB',[(g,b,r),(b,r,g),(r,b,g),(g,r,b),(b,g,r)][i-1])
 im=ImageEnhance.Color(im).enhance(.6+i*.14)
 buf=io.BytesIO();im.save(buf,format='JPEG',quality=90);fixtures.append(buf.getvalue())
keys=['1758782551890','1635861105962','1741893041975','1710762635726','1532586733327','Milford']
results=[]
def check(value,label):
 if not value:raise AssertionError(label)
 results.append(label);print('PASS',label,flush=True)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium') or p.chromium.executable_path,headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
 page=browser.new_page(viewport={'width':1440,'height':1040},device_scale_factor=1)
 errors=[];logs=[]
 page.on('pageerror',lambda e: errors.append(str(e)))
 page.on('console',lambda e: logs.append(e.type+': '+e.text))
 def fixture(route):
  i=next((i for i,k in enumerate(keys) if k in route.request.url),0)
  route.fulfill(status=200,content_type='image/jpeg',headers={'Access-Control-Allow-Origin':'*'},body=fixtures[i])
 page.route('https://**/*',fixture)
 page.set_content((ROOT/'destination-rolodex-transitions.html').read_text(),wait_until='load')
 page.wait_for_function('window.destinationCard && destinationCard.selectedIndex===0')
 page.evaluate('destinationCard.pause()')
 page.wait_for_timeout(1200)
 print('ENGINE',page.evaluate('({available:destinationCard._fx.available,error:destinationCard._fx.error})'))
 print('ERRORS',errors,'CONSOLE',logs[-8:])
 check(page.evaluate('destinationCard._fx.available'), 'WebGL shader compiles')
 check(page.locator('destination-rolodex .country-row').count()==9, 'Original infinite picker retained')
 check(page.locator('.effect-option').count()==4,'Four live mode selectors')
 page.screenshot(path=str(OUT/'desktop-initial.png'),full_page=True)
 # Deterministic replay and frame inspection.
 for mode in ['morph','liquid','orbit','slices','fade']:
  page.evaluate('(mode)=>{destinationCard.transition=mode;}',mode)
  check(page.evaluate('destinationCard.seekTransition(.5)'),mode+' scrubs')
  page.wait_for_timeout(70)
  check(page.evaluate('destinationCard._fx.active && Math.abs(destinationCard._fx.progress-.5)<.001'),mode+' active at midpoint')
  page.screenshot(path=str(OUT/f'{mode}-midpoint.png'),full_page=True)
  for value in [0,1]:
   page.evaluate('(v)=>destinationCard.seekTransition(v)',value)
   page.wait_for_timeout(40)
   check(page.evaluate('destinationCard.selectedIndex')==(0 if value==0 else 1),mode+f' selection at {value}')
  # Capturing GL error after drawing ensures actual render-path validity.
  check(page.evaluate('destinationCard._fx.gl.getError()')==0, mode+' renders without GL errors')
 page.evaluate('destinationCard.transition="morph";destinationCard.transitionDuration=650;')
 check(page.evaluate('destinationCard.replayTransition()'),'Replay starts')
 page.wait_for_function('!destinationCard._previewing && !destinationCard._fx.active',timeout=10000)
 check(page.evaluate('!destinationCard._previewing && !destinationCard._fx.active'),'Replay releases control cleanly')
 check(page.evaluate('destinationCard.selectedIndex===1 && destinationCard._displayedId==="jp"'),'Replay commits matching destination and photo')
 # Normal picker interactions after a scrub.
 page.evaluate('destinationCard.seekTransition(.3)')
 page.locator('destination-rolodex .next').click()
 page.wait_for_timeout(1450)
 check(page.evaluate('!destinationCard._previewing'),'Navigation exits scrub mode')
 check(page.evaluate('destinationCard.selectedIndex===1 && destinationCard._displayedId==="jp"'),'Navigation after scrub matches selected photo')
 page.evaluate('destinationCard.goTo(0)')
 page.wait_for_timeout(1300)
 page.locator('destination-rolodex .picker').focus()
 page.keyboard.press('ArrowUp');page.wait_for_timeout(1400)
 check(page.evaluate('destinationCard.selectedIndex===5 && destinationCard._displayedId==="nz"'),'Backward loop works with transitions')
 page.keyboard.press('ArrowDown');page.wait_for_timeout(1400)
 check(page.evaluate('destinationCard.selectedIndex===0 && destinationCard._displayedId==="ph"'),'Forward loop works with transitions')
 page.locator('destination-rolodex .look-toggle').click()
 check(page.evaluate('destinationCard.view')=='look','Look-around retained')
 page.locator('destination-rolodex .zoom-in').click()
 check(page.evaluate('destinationCard._targetZoom>1'),'Zoom retained')
 page.locator('destination-rolodex .scene').focus();page.keyboard.press('Escape')
 check(page.evaluate('destinationCard.view')=='browse','Escape restores browsing')
 page.evaluate('destinationCard.goTo(2);destinationCard.goTo(4);destinationCard.goTo(3)')
 page.wait_for_timeout(1600)
 check(page.evaluate('destinationCard.selectedIndex===3 && destinationCard._displayedId==="no"'),'Rapid navigation settles correctly')
 check(not errors,'No browser JavaScript errors')
 # Mobile layout / input.
 page.set_viewport_size({'width':390,'height':844})
 page.wait_for_timeout(250)
 check(page.evaluate('document.documentElement.scrollWidth<=innerWidth'),'Mobile has no horizontal overflow')
 page.screenshot(path=str(OUT/'mobile.png'),full_page=True)
 # Reduced-motion behavior.
 page.emulate_media(reduced_motion='reduce');page.wait_for_timeout(200)
 page.evaluate('destinationCard.replayTransition()')
 page.wait_for_timeout(300)
 check(page.evaluate('!destinationCard._fx.active && !destinationCard._auto'),'Reduced motion disables the shader animation')
 page.close()
 # Context denied: base component survives.
 fallback=browser.new_page(viewport={'width':1200,'height':850})
 fallback.evaluate("(()=>{const old=HTMLCanvasElement.prototype.getContext;HTMLCanvasElement.prototype.getContext=function(t,...a){return String(t).includes('webgl')?null:old.call(this,t,...a);};})()")
 fallback.route('https://**/*',fixture)
 fallback.set_content((ROOT/'destination-rolodex-transitions.html').read_text(),wait_until='load')
 fallback.wait_for_function('window.destinationCard && destinationCard.selectedIndex===0')
 fallback.evaluate('destinationCard.pause();destinationCard.next()');fallback.wait_for_timeout(900)
 check(fallback.evaluate('destinationCard.transitionRenderer==="crossfade" && destinationCard.selectedIndex===1'),'No-WebGL fallback keeps navigation working')
 fallback.close();browser.close()
(ROOT/'tests/transition-results.json').write_text(json.dumps({'passed':results,'errors':errors,'fixture_note':'Browser tests use distinct, local image fixtures. They do not verify the external photo hosts.'},indent=2))
print(json.dumps({'passed':len(results),'errors':errors}))
