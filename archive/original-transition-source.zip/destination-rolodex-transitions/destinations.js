window.DEMO_DESTINATIONS = [
  {
    "id": "ph",
    "country": "Philippines",
    "location": "Coron, Palawan",
    "region": "Asia",
    "color": "#166a73",
    "description": "Limestone cliffs and clear blue lagoons. Find a quiet cove, take a swim, and explore the islands by boat.",
    "media": {
      "type": "image",
      "src": "https://images.unsplash.com/photo-1758782551890-0f47a570859c?auto=format&fit=crop&w=1400&q=85",
      "preview": "assets/philippines-preview.jpg",
      "position": "50% 52%",
      "alt": "Green limestone cliffs surrounding a blue lagoon in Coron, Philippines",
      "credit": "Florian Delée",
      "source": "https://unsplash.com/photos/lush-green-mountains-surround-a-tranquil-blue-lagoon-9bmkwiFUV6o"
    }
  },
  {
    "id": "jp",
    "country": "Japan",
    "location": "Mount Fuji, Yamanashi",
    "region": "Asia",
    "color": "#607f98",
    "description": "A still lake beneath Mount Fuji. Take the slower route around the shore and make time for the view.",
    "media": {
      "type": "image",
      "src": "https://images.unsplash.com/photo-1635861105962-ff85ca1ce355?auto=format&fit=crop&w=1400&q=85",
      "position": "50% 47%",
      "alt": "Mount Fuji reflected in a calm lake in Japan",
      "credit": "katsuma tanaka",
      "source": "https://unsplash.com/photos/a-mountain-with-a-lake-in-front-of-it-lS1DG90Rhmw"
    }
  },
  {
    "id": "it",
    "country": "Italy",
    "location": "Lago di Braies, Dolomites",
    "region": "Europe",
    "color": "#397779",
    "description": "Alpine water beneath the Dolomites. Follow the lakeside trail, or take a boat out into the morning light.",
    "media": {
      "type": "image",
      "src": "https://images.unsplash.com/photo-1741893041975-94a0e8656209?auto=format&fit=crop&w=1400&q=85",
      "position": "50% 49%",
      "alt": "A dock on Lago di Braies with mountains and trees beyond",
      "credit": "Micah & Sammie Chaffin",
      "source": "https://unsplash.com/photos/a-beautiful-mountain-lake-with-dock-zWTmywY3nyg"
    }
  },
  {
    "id": "no",
    "country": "Norway",
    "location": "Lofoten Islands",
    "region": "Europe",
    "color": "#426578",
    "description": "Steep mountains and small coastal villages. Follow the water through Lofoten, with plenty of stops along the way.",
    "media": {
      "type": "image",
      "src": "https://images.unsplash.com/photo-1710762635726-531b4a22d4ca?auto=format&fit=crop&w=1400&q=85",
      "position": "50% 50%",
      "alt": "Mountain and coastal scenery in the Lofoten Islands, Norway",
      "credit": "Bingqi Huang",
      "source": "https://unsplash.com/photos/NxjtJghBaHM"
    }
  },
  {
    "id": "is",
    "country": "Iceland",
    "location": "Skógafoss, South Coast",
    "region": "Europe",
    "color": "#526e60",
    "description": "Waterfalls, moss-covered cliffs, and open skies. Walk toward the spray, then head on along the south coast.",
    "media": {
      "type": "image",
      "src": "https://images.unsplash.com/photo-1532586733327-54ac07aa1154?auto=format&fit=crop&w=1400&q=85",
      "position": "50% 50%",
      "alt": "Skógafoss waterfall in Iceland",
      "credit": "Denys Nevozhai",
      "source": "https://unsplash.com/photos/7AVU4gIH2cE"
    }
  },
  {
    "id": "nz",
    "country": "New Zealand",
    "location": "Milford Sound, Fiordland",
    "region": "Oceania",
    "color": "#425a53",
    "description": "Waterfalls spilling down forested rock faces. Get out on the water for a closer look at Milford Sound.",
    "media": {
      "type": "image",
      "src": "https://thumb.wikimedia.org/wikipedia/commons/thumb/a/ac/Milford_Sound%2C_New_Zealand_%28Unsplash_lSUx0xM2bEo%29.jpg/1280px-Milford_Sound%2C_New_Zealand_%28Unsplash_lSUx0xM2bEo%29.jpg?utm_campaign=index&utm_content=thumbnail&utm_source=commons.wikimedia.org",
      "position": "50% 50%",
      "alt": "Stirling Falls descending into Milford Sound, New Zealand",
      "credit": "Lindsey Costa",
      "source": "https://commons.wikimedia.org/wiki/File:Milford_Sound,_New_Zealand_(Unsplash_lSUx0xM2bEo).jpg"
    }
  }
];
