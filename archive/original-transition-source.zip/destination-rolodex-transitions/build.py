#!/usr/bin/env python3
"""Build the portable HTML and data script. No third-party Python packages required.

Run python build.py --offline on a connected machine to download and embed all photos.
The default build embeds code and the local preview, but keeps the full photos online.
"""
from __future__ import annotations
import argparse
import base64
import json
import mimetypes
import re
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent

def data_uri(path: Path) -> str:
    mime = mimetypes.guess_type(path.name)[0] or 'application/octet-stream'
    return f'data:{mime};base64,' + base64.b64encode(path.read_bytes()).decode('ascii')

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--offline', action='store_true', help='Download and embed destination photos; requires internet.')
    args = parser.parse_args()
    data = json.loads((ROOT / 'destinations.json').read_text(encoding='utf-8'))
    for d in data:
        media = d['media']
        if args.offline and media.get('type', 'image') == 'image':
            path = ROOT / 'assets' / f"{d['id']}.jpg"
            if not path.exists():
                request = Request(media['src'], headers={'User-Agent': 'DestinationRolodexDemo/1.0 (local build)'})
                try:
                    with urlopen(request, timeout=45) as response:
                        if not response.headers.get('Content-Type', '').startswith('image/'):
                            raise ValueError('The remote URL did not return an image.')
                        contents = response.read(20_000_001)
                        if len(contents) > 20_000_000:
                            raise ValueError('The photo exceeds the 20 MB build limit.')
                    path.write_bytes(contents)
                except Exception as error:
                    raise SystemExit(f"Could not download {d['country']}: {error}. No offline build was produced.") from error
            media['src'] = str(path.relative_to(ROOT))
            print(f"Local asset ready: {d['country']}")
    (ROOT / 'destinations.js').write_text('window.DEMO_DESTINATIONS = ' + json.dumps(data, ensure_ascii=False, indent=2) + ';\n', encoding='utf-8')
    for d in data:
        for key in ['src', 'preview', 'poster']:
            value = d['media'].get(key)
            if value and not value.startswith(('https:', 'http:', 'data:', 'blob:')):
                d['media'][key] = data_uri(ROOT / value)
    html = (ROOT / 'index.html').read_text(encoding='utf-8')
    html = html.replace('<link rel="stylesheet" href="demo.css">', '<style>' + (ROOT / 'demo.css').read_text(encoding='utf-8') + '</style>')
    js = {
        'transition-engine.js': (ROOT / 'transition-engine.js').read_text(encoding='utf-8'),
        'lab.js': (ROOT / 'lab.js').read_text(encoding='utf-8'),
        'rolodex.js': (ROOT / 'rolodex.js').read_text(encoding='utf-8'),
        'destinations.js': 'window.DEMO_DESTINATIONS = ' + json.dumps(data, ensure_ascii=False).replace('</', '<\\/') + ';',
        'demo.js': (ROOT / 'demo.js').read_text(encoding='utf-8'),
    }
    for filename, script in js.items():
        # Escape literal closing script tags without touching JavaScript operators.
        safe_script = re.sub(r'</script', r'<\\/script', script, flags=re.IGNORECASE)
        html = html.replace(f'<script src="{filename}"></script>', '<script>\n' + safe_script + '\n</script>')
    name = 'destination-rolodex-transitions-offline.html' if args.offline else 'destination-rolodex-transitions.html'
    (ROOT / name).write_text(html, encoding='utf-8')
    print(f'Built {name} ({len(html.encode("utf-8")):,} bytes)')

if __name__ == '__main__':
    main()
